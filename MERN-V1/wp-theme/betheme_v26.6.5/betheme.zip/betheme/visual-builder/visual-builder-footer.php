<?php

do_action( 'in_admin_footer' );
do_action( 'admin_footer' );
do_action( 'admin_print_footer_scripts' );

?>
</body>
</html>
